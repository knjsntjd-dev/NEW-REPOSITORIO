/* RLP · carrinho lateral leve (sem dependências). API: window.RLPCart.add(itens, cupom), .open(), .close() */
(function(){
  'use strict';
  var root = document.getElementById('rlp-cart');
  if (!root) return;

  var cfg = {};
  try { cfg = JSON.parse(root.getAttribute('data-cfg')); } catch(e){}
  var rota = (root.getAttribute('data-route') || '/cart').replace(/\/$/, '');
  var $ = function(s){ return root.querySelector(s); };
  var body = $('[data-rc-body]'), foot = $('[data-rc-foot]');
  var KEY = 'rlp_cupom';
  var UPS = [];
  try { UPS = JSON.parse((document.querySelector('[data-rc-ups]') || {}).textContent || '[]'); } catch(e){}
  var NIV = (cfg.niveis || []).filter(function(n){ return n.v > 0; }).sort(function(a, b){ return a.v - b.v; });
  if (!NIV.length) NIV = [{ v: cfg.meta || 0, p: cfg.premio || '' }];
  var ultimoFoco = null;

  function money(c){
    var f = cfg.money || '€{{amount_with_comma_separator}}';
    var v = (c / 100);
    var n = /no_decimals/.test(f) ? String(Math.round(v)) : v.toFixed(2);
    if (/comma/.test(f)) n = n.replace('.', ',');
    return f.replace(/\{\{\s*[a-z_]+\s*\}\}/, n);
  }
  function esc(t){ return String(t == null ? '' : t).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function img(u, w){ if (!u) return ''; return u + (u.indexOf('?') > -1 ? '&' : '?') + 'width=' + w; }

  function api(url, dados){
    return fetch(url, {
      method: dados ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: dados ? JSON.stringify(dados) : undefined,
      credentials: 'same-origin'
    }).then(function(r){
      return r.json().then(function(j){ if (!r.ok) throw j; return j; });
    });
  }

  /* ── Cupom: guardado só no navegador e validado contra o carrinho ── */
  function lerCupom(){ try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch(e){ return null; } }
  function gravarCupom(c){ try { c ? localStorage.setItem(KEY, JSON.stringify(c)) : localStorage.removeItem(KEY); } catch(e){} }
  function cupomValido(cart){
    var c = lerCupom();
    if (!c || !c.code) return null;
    if (c.tipo === 'combo'){
      var n = cart.items.filter(function(i){ return i.properties && i.properties._combo === c.code; }).length;
      return n >= 2 ? c.code : null;
    }
    if (c.tipo === 'pack'){
      var q = 0;
      cart.items.forEach(function(i){ if (String(i.product_id) === String(c.productId)) q += i.quantity; });
      return q >= c.q ? c.code : null;
    }
    return c.code;
  }

  /* ── Render ── */
  function render(cart){
    var n = cart.item_count;
    $('[data-rc-count]').textContent = n ? '(' + n + ')' : '';
    atualizarBolha(n);

    var bar = $('[data-rc-bar]');
    if (cfg.barra){
      bar.hidden = false;
      var tot = cart.items_subtotal_price != null ? cart.items_subtotal_price : cart.total_price, topo = NIV[NIV.length - 1].v;
      var prox = NIV.filter(function(x){ return x.v > tot; })[0];
      var feitos = NIV.filter(function(x){ return x.v <= tot; });
      $('[data-rc-bar-txt]').textContent = prox
        ? String(cfg.msg).replace('[valor]', money(prox.v - tot)).replace('[premio]', prox.p)
        : String(cfg.ok).replace('[premio]', (feitos[feitos.length - 1] || NIV[0]).p);
      $('[data-rc-bar-fill]').style.width = (topo <= 0 ? 100 : Math.min(100, tot / topo * 100)) + '%';
      var trilho = $('[data-rc-bar-fill]').parentNode;
      [].forEach.call(trilho.querySelectorAll('.rc-mk'), function(m){ m.remove(); });
      var lv = $('[data-rc-lv]');
      if (NIV.length > 1){
        NIV.slice(0, -1).forEach(function(x){
          var m = document.createElement('span');
          m.className = 'rc-mk' + (x.v <= tot ? ' ok' : '');
          m.style.left = (x.v / topo * 100) + '%';
          trilho.appendChild(m);
        });
        lv.innerHTML = NIV.map(function(x){ return '<span' + (x.v <= tot ? ' class="ok"' : '') + '>' + (x.v <= tot ? '✓ ' : '') + money(x.v) + ' · ' + esc(x.p) + '</span>'; }).join('');
        lv.hidden = false;
      } else lv.hidden = true;
    } else bar.hidden = true;

    if (!n){
      body.innerHTML = $('[data-rc-empty]').innerHTML;
      foot.hidden = true;
      gravarCupom(null);
      return;
    }

    body.innerHTML = cart.items.map(function(i){
      var opts = (i.options_with_values || []).filter(function(o){ return o.value !== 'Default Title'; })
        .map(function(o){ return esc(o.value); }).join(' · ');
      var combo = i.properties && i.properties._combo;
      var cheio = i.original_line_price > i.final_line_price ? '<s>' + money(i.original_line_price) + '</s>' : '';
      return '<div class="rc-ln" data-key="' + esc(i.key) + '">' +
        (i.image ? '<img src="' + esc(img(i.image, 160)) + '" alt="" width="76" height="76" loading="lazy">' : '<span></span>') +
        '<div><a class="rc-t" href="' + esc(i.url) + '">' + esc(i.product_title) + '</a>' +
          (opts ? '<p class="rc-v">' + opts + '</p>' : '') +
          (combo ? '<span class="rc-tag">' + esc(cfg.combo || 'Combo') + '</span>' : '') +
          '<div class="rc-q"><button type="button" data-q="-1" aria-label="Diminuir">−</button><span>' + i.quantity + '</span><button type="button" data-q="1" aria-label="Aumentar">+</button></div>' +
        '</div>' +
        '<div class="rc-p">' + cheio + money(i.final_line_price) + '<button type="button" class="rc-rm" data-rm>Remover</button></div>' +
      '</div>';
    }).join('') + ofertas(cart);

    foot.hidden = false;
    var desc = $('[data-rc-desc]');
    if (!desc){
      desc = document.createElement('div');
      desc.className = 'rc-row rc-desc'; desc.setAttribute('data-rc-desc', '');
      $('[data-rc-total]').parentNode.parentNode.insertBefore(desc, $('[data-rc-total]').parentNode);
    }
    var aplic = (cart.cart_level_discount_applications || []).filter(function(d){ return d.total_allocated_amount > 0; });
    desc.hidden = !aplic.length;
    desc.innerHTML = aplic.map(function(d){ return '<span>' + esc(d.title) + '</span><span>−' + money(d.total_allocated_amount) + '</span>'; }).join('');
    $('[data-rc-total]').textContent = money(cart.total_price);
    var code = cupomValido(cart);
    var aviso = $('[data-rc-cupom]');
    aviso.hidden = !code;
    if (code) aviso.textContent = String(cfg.cupom || '').replace('[cupom]', code);
    var params = [];
    if (code) params.push('discount=' + encodeURIComponent(code));
    var clique = location.search.match(/[?&]fbclid=([^&]+)/);
    if (clique) params.push('fbclid=' + clique[1]);
    $('[data-rc-checkout]').setAttribute('href', '/checkout' + (params.length ? '?' + params.join('&') : ''));
  }

  /* Oferta: produtos sugeridos que ainda não estão no carrinho */
  function ofertas(cart){
    var noCarrinho = {};
    cart.items.forEach(function(i){ noCarrinho[i.product_id] = 1; });
    var lista = UPS.filter(function(u){ return !noCarrinho[u.id] && u.v.some(function(v){ return v.a; }); }).slice(0, cfg.upN || 2);
    if (!lista.length) return '';
    return '<div class="rc-up"><h3>' + esc(cfg.upT || '') + '</h3>' + lista.map(function(u){
      var vs = u.v.filter(function(v){ return v.a; }), v = vs[0];
      var sel = vs.length > 1 ? '<select data-up-var aria-label="Opção">' + vs.map(function(x){ return '<option value="' + x.id + '">' + esc(x.t) + '</option>'; }).join('') + '</select>' : '<input type="hidden" data-up-var value="' + v.id + '">';
      return '<div class="rc-ui">' + (u.i ? '<img src="' + esc(u.i) + '" alt="" width="56" height="56" loading="lazy">' : '<span></span>') +
        '<div><b>' + esc(u.t) + '</b><small>' + money(v.p) + (v.c > v.p ? '<s>' + money(v.c) + '</s>' : '') + '</small>' + sel + '</div>' +
        '<button type="button" class="rc-ub" data-up-add>' + esc(cfg.upB || '+') + '</button></div>';
    }).join('') + '</div>';
  }

  function atualizarBolha(n){
    var b = document.getElementById('cart-icon-bubble');
    if (!b) return;
    var c = b.querySelector('.cart-count');
    if (!n){ if (c) c.remove(); return; }
    if (!c){ c = document.createElement('span'); c.className = 'cart-count'; c.setAttribute('aria-hidden', 'true'); b.appendChild(c); }
    c.textContent = n > 99 ? 99 : n;
  }

  function carregar(){ return api(rota + '.js').then(render); }

  /* ── Abrir / fechar ── */
  function open(){
    if (root.classList.contains('is-open')) return carregar();
    ultimoFoco = document.activeElement;
    root.hidden = false;
    document.documentElement.classList.add('rlp-cart-lock');
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ root.classList.add('is-open'); }); });
    setTimeout(function(){ var x = $('.rc-x'); if (x) x.focus({ preventScroll: true }); }, 50);
    return carregar();
  }
  function close(){
    root.classList.remove('is-open');
    document.documentElement.classList.remove('rlp-cart-lock');
    setTimeout(function(){ root.hidden = true; }, 300);
    if (ultimoFoco && ultimoFoco.focus) ultimoFoco.focus({ preventScroll: true });
  }

  root.addEventListener('click', function(e){
    if (e.target.closest('[data-rc-close]')){ e.preventDefault(); close(); return; }
    var ub = e.target.closest('[data-up-add]');
    if (ub){
      var vid = ub.parentNode.querySelector('[data-up-var]').value;
      ub.disabled = true;
      api(rota + '/add.js', { items: [{ id: +vid, quantity: 1 }] }).then(carregar).catch(function(err){
        ub.disabled = false;
        alert((err && (err.description || err.message)) || 'Não foi possível adicionar.');
      });
      return;
    }
    var ln = e.target.closest('.rc-ln');
    if (!ln) return;
    var key = ln.getAttribute('data-key');
    var q = parseInt(ln.querySelector('.rc-q span').textContent, 10);
    var nova = null;
    var bq = e.target.closest('[data-q]');
    if (bq) nova = Math.max(0, q + parseInt(bq.getAttribute('data-q'), 10));
    if (e.target.closest('[data-rm]')) nova = 0;
    if (nova === null) return;
    ln.classList.add('rc-load');
    api(rota + '/change.js', { id: key, quantity: nova }).then(render).catch(function(err){
      ln.classList.remove('rc-load');
      alert((err && (err.description || err.message)) || 'Não foi possível atualizar o carrinho.');
    });
  });
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && root.classList.contains('is-open')) close(); });

  /* Ícone do carrinho desta página abre este carrinho (e não a página /cart) */
  document.addEventListener('click', function(e){
    var a = e.target.closest('#cart-icon-bubble, [data-cart-open], a[href="/cart"], a[href="' + rota + '"]');
    if (!a || root.contains(a)) return;
    e.preventDefault();
    e.stopPropagation();
    open();
  }, true);

  /* ── API pública ── */
  window.RLPCart = {
    open: open,
    close: close,
    add: function(itens, cupom, opts){
      return api(rota + '/add.js', { items: itens }).then(function(){
        if (cupom) gravarCupom(cupom);
        if (opts && opts.checkout){
          return carregar().then(function(){ location.href = $('[data-rc-checkout]').getAttribute('href'); });
        }
        if (cfg.abrir !== false) return open();
        return carregar();
      });
    }
  };
})();
